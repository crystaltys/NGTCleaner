import serial
from classify_picamera import classify
from firebase import firebase

firebase = firebase.FirebaseApplication('https://oip-database-default-rtdb.asia-southeast1.firebasedatabase.app/',None)

def read(dev):
    while True:
        #print('waiting...')
        if dev.in_waiting>0:
            data = dev.readline().decode('utf-8').rstrip()
            print('\ndata received from arduino ' + str(data))
            if data.split(':')[0] == 'temp':
                temp = data.split(':')[1]
                firebase.put("/data", "/temp", str(temp))
            elif data.split(':')[0] == 'humidity':
                humidity = data.split(':')[1]
                firebase.put("/data", "/humidity", str(humidity))
            elif data.split(':')[0] == 'status':
                status = data.split(':')[1]
                firebase.put("/data", "/status", str(status))
            elif data.split(':')[0] == 'error':
                error = data.split(':')[1]
                firebase.put("/data", "/error", str(error))
            elif data.split(':')[0] == 'stage':
                stage = data.split(':')[1]
                firebase.put("/data", "/stage", str(stage))    
            elif data == '01' or '02' or '03' or '04' or '05' or '06':
                detect_residue(dev,data)
            else:
                print('data not recognised')
            
def detect_residue(dev,syringe):
    label = classify()
    print('clean or dirty' + str(label))
    # 0 - dirty 1 - clean 
    if (syringe == '6'):
        return
    elif label == '0':
        for i in range(1):
            print('writing to arduino')
            dev.write(b'0')
        
    else:
        for i in range(1):
            print('writing to arduino')
            dev.write(b'1')
        read(dev)

ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
ser.flush()
read(ser)
    
            
